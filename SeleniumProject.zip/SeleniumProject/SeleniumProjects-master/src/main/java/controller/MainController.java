package controller;

import service.TarkiAutomation;

public class MainController {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TarkiAutomation.setChromeFunctinality();
	}

}
